import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'src'))
from enterprise_env import EnterpriseWorkflowSimulator
from reward_model import DomainConstrainedRewardModel


def test_reward_components_are_present():
    sim = EnterpriseWorkflowSimulator(seed=123)
    traj = sim.simulate_trajectory(
        trajectory_id='test_001', model='Agentic RLHF', iteration=1,
        workflow_type='ITSM incident triage', alignment_score=88.8,
        task_success_probability=90.7, violation_probability=5.9,
    )
    reward = DomainConstrainedRewardModel()
    comps = reward.reward_components(traj)
    assert 'task_reward' in comps
    assert 'alignment_reward' in comps
    assert 'violation_penalty' in comps
    assert 'final_reward' in comps
    assert -1.0 <= comps['final_reward'] <= 1.0