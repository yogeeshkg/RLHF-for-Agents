import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'src'))
from baselines import generate_training_logs


def test_training_logs_are_reproducible():
    a = generate_training_logs(seed=42)
    b = generate_training_logs(seed=42)
    assert a.equals(b)
    assert len(a) == 500