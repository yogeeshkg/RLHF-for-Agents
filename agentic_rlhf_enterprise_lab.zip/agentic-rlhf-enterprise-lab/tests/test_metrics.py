import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'src'))
import pandas as pd
from baselines import generate_training_logs
from metrics import final_checkpoint_metrics, feedback_cost_index


def test_final_metrics_match_paper_targets():
    logs = generate_training_logs()
    summary = final_checkpoint_metrics(logs)
    row = summary[summary['model'] == 'Agentic RLHF'].iloc[0]
    assert round(row['alignment_score'], 1) == 88.8
    assert round(row['task_success_rate'], 1) == 90.7
    assert round(row['violation_rate'], 1) == 5.9


def test_feedback_cost_index_full_human_is_100():
    assert feedback_cost_index(c_h=10, c_a=1, n_h=100, n_a=0) == 100.0


def test_feedback_cost_index_reduces_with_ai_feedback():
    assert feedback_cost_index(c_h=10, c_a=1, n_h=40, n_a=60) < 100.0