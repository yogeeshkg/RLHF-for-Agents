# Reproducibility

## Fixed seeds

- Aggregate training curves: seed `42`
- Enterprise trajectory simulator: seed `7`

## One-command reproduction

```bash
python src/run_all.py
```

## Expected final checkpoint values

| Model | Alignment | Task success | Violation |
|---|---:|---:|---:|
| SFT | 63.5 | 65.1 | 18.9 |
| Standard RLHF | 75.7 | 76.7 | 13.2 |
| DPO | 80.7 | 81.9 | 10.3 |
| Agentic RLHF | 88.8 | 90.7 | 5.9 |

## Figures generated

- `figures/training_alignment_curve.png`
- `figures/training_task_success_curve.png`
- `figures/training_violation_curve.png`
- `figures/feedback_cost_coverage_curve.png`