# Optional Advanced Extension: Real Model Training

The default lab is CPU-friendly and simulation-based. To move toward real training, use:

- HuggingFace Transformers
- HuggingFace Datasets
- TRL DPOTrainer
- TRL PPOTrainer
- public preference datasets such as HH-RLHF, UltraFeedback, and HelpSteer2

## Suggested stages

1. Replace synthetic response pairs with HH-RLHF or UltraFeedback samples.
2. Train a reward model or use a small reward-model proxy.
3. Run DPOTrainer as a response-level baseline.
4. Integrate the enterprise trajectory simulator to produce trajectory-level rewards.
5. Use PPOTrainer with `R_final(trajectory)` as the reward signal.

## Important caution

Full PPO/RLHF training needs GPU resources and careful safety review. The CPU lab proves the mechanism and metric structure first.