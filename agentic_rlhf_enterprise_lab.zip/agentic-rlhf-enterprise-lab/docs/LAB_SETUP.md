# Lab Setup Guide

This guide explains how to run the CPU-friendly proof lab for the paper:

**Agentic AI and Post-Training Alignment: Scaling RLHF for Autonomous Enterprise Systems**

## 1. Create environment

### macOS/Linux

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 2. Run the complete lab

```bash
python src/run_all.py
```

This regenerates:

- datasets
- trajectory records
- final metrics
- ablation table
- plots
- inference report

## 3. Generate each stage separately

```bash
python src/run_experiments.py
python src/generate_figures.py
python src/analyze_results.py
```

## 4. Run tests

```bash
pytest
```

Expected output:

```text
5 passed
```

## 5. What proves the paper's crux?

The lab compares four configurations:

1. SFT
2. Standard RLHF
3. DPO
4. Agentic RLHF

The full Agentic RLHF approach adds trajectory reward, hybrid feedback, policy constraints, and domain-aware reward penalties. The expected result is higher alignment score, higher task success rate, and lower policy violation rate.