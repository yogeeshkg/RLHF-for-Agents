# Paper-to-Code Mapping

| Paper concept | Code implementation |
|---|---|
| Trajectory representation | `src/trajectory.py` |
| Enterprise workflow simulator | `src/enterprise_env.py` |
| Hybrid feedback | `src/hybrid_feedback.py` |
| Policy constraints | `src/policy_constraints.py` |
| Domain-constrained reward | `src/reward_model.py` |
| SFT/RLHF/DPO/Agentic RLHF curves | `src/baselines.py` |
| Metrics | `src/metrics.py` |
| Training logs | `data/processed/training_logs.csv` |
| Final checkpoint table | `data/processed/final_metrics_summary.csv` |
| Ablation study | `data/processed/ablation_summary.csv` |
| ITSM case study | `data/processed/itsm_case_study_outcomes.csv` |
| Figures | `figures/` |

## Formula mapping

The paper formula:

```text
R_final = eta * R_task + beta * R_align - lambda * R_violation - rho * R_uncertainty
```

is implemented in:

```text
src/reward_model.py -> DomainConstrainedRewardModel.final_reward()
```

The hybrid feedback formula:

```text
R_align = alpha * R_human + (1 - alpha) * R_AI
```

is implemented in:

```text
src/hybrid_feedback.py -> HybridFeedbackEngine.alignment_reward()
```