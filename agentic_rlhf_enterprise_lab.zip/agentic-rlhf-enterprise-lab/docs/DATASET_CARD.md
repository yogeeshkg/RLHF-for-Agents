# Dataset Card

## Dataset name

`agentic-rlhf-enterprise-lab`

## Included datasets

- `data/processed/training_logs.csv`
- `data/raw/simulated_enterprise_trajectories.csv`
- `data/processed/final_metrics_summary.csv`
- `data/processed/ablation_summary.csv`
- `data/processed/itsm_case_study_outcomes.csv`

## Dataset type

Synthetic, deterministic, reproducible benchmark traces.

## Purpose

The dataset is designed to prove the mechanism behind trajectory-aware enterprise alignment. It is not private enterprise data and does not contain personal information.

## External preference datasets

The paper references public datasets such as HH-RLHF, UltraFeedback, and HelpSteer2 as relevant preference/reward-modeling sources. They are not bundled in this package.

## Limitations

The included traces are CPU-friendly benchmark traces. They are suitable for proving the framework and reproducing figures, not for claiming full production-scale PPO/DPO training.