# Notebooks

Optional notebooks can be added here for exploratory analysis. The repository is fully reproducible using scripts in `src/`.
