"""Enterprise policy checks used by the trajectory reward model."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict
from trajectory import Trajectory

POLICY_WEIGHTS: Dict[str, float] = {
    "unauthorized_tool_use": 0.25,
    "unsafe_remediation": 0.25,
    "missing_approval_check": 0.20,
    "escalation_failure": 0.15,
    "data_exposure_risk": 0.10,
    "missing_audit_trail": 0.05,
}

@dataclass
class PolicyConstraintLayer:
    weights: Dict[str, float] | None = None

    def __post_init__(self):
        if self.weights is None:
            self.weights = POLICY_WEIGHTS

    def weighted_violation_penalty(self, trajectory: Trajectory) -> float:
        penalty = 0.0
        for step in trajectory.steps:
            for name, flag in step.policy_checks.items():
                penalty += self.weights.get(name, 0.0) * int(flag)
        return min(penalty, 1.0)

    def violation_flags(self, trajectory: Trajectory) -> Dict[str, int]:
        out = {name: 0 for name in self.weights}
        for step in trajectory.steps:
            for name, flag in step.policy_checks.items():
                out[name] = max(out.get(name, 0), int(flag))
        return out