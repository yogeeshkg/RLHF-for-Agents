"""Central configuration for the Agentic RLHF enterprise lab."""
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_PROCESSED = ROOT / "data" / "processed"
FIGURES = ROOT / "figures"
RESULTS = ROOT / "results"

SEED = 42
N_ITERATIONS = 500
TAIL_WINDOW = 50
N_TRAJECTORY_SAMPLES = 20

MODELS = ["SFT", "Standard RLHF", "DPO", "Agentic RLHF"]
WORKFLOWS = ["ITSM incident triage", "ERP transaction validation", "DevSecOps change review"]

TARGET_FINAL_METRICS = {
    "SFT": {"alignment_score": 63.5, "task_success_rate": 65.1, "violation_rate": 18.9},
    "Standard RLHF": {"alignment_score": 75.7, "task_success_rate": 76.7, "violation_rate": 13.2},
    "DPO": {"alignment_score": 80.7, "task_success_rate": 81.9, "violation_rate": 10.3},
    "Agentic RLHF": {"alignment_score": 88.8, "task_success_rate": 90.7, "violation_rate": 5.9},
}

MODEL_KEYS = {
    "SFT": "sft",
    "Standard RLHF": "standard_rlhf",
    "DPO": "dpo",
    "Agentic RLHF": "agentic_rlhf",
}

@dataclass(frozen=True)
class RewardWeights:
    eta_task: float = 0.45
    beta_alignment: float = 0.35
    lambda_violation: float = 0.15
    rho_uncertainty: float = 0.05
    alpha_human: float = 0.65

DEFAULT_REWARD_WEIGHTS = RewardWeights()