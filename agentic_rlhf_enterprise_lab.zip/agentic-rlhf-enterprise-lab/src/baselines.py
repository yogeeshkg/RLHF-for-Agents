"""Baseline curve generators for SFT, response-level RLHF, DPO, and Agentic RLHF."""
import numpy as np
import pandas as pd
from config import SEED, N_ITERATIONS

iters = np.arange(1, N_ITERATIONS + 1)

def _growth(start, end, rate, noise, rng):
    vals = end - (end - start) * np.exp(-rate * iters)
    vals += rng.normal(0, noise, len(iters))
    return vals

def _decay(start, end, rate, noise, rng):
    vals = end + (start - end) * np.exp(-rate * iters)
    vals += rng.normal(0, noise, len(iters))
    return vals

def _force_tail_mean(vals, target, lo=0, hi=100):
    vals = np.clip(vals, lo, hi)
    vals[-50:] = vals[-50:] - vals[-50:].mean() + target
    return np.clip(vals, lo, hi)

def generate_training_logs(seed: int = SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    specs = {
        'sft_alignment_score': (_growth(55,64,0.006,0.7,rng), 63.5),
        'standard_rlhf_alignment_score': (_growth(58,76,0.008,0.8,rng), 75.7),
        'dpo_alignment_score': (_growth(60,81,0.009,0.75,rng), 80.7),
        'agentic_rlhf_alignment_score': (_growth(61,89,0.011,0.65,rng), 88.8),
        'sft_task_success_rate': (_growth(58,66,0.005,0.8,rng), 65.1),
        'standard_rlhf_task_success_rate': (_growth(60,77,0.008,0.85,rng), 76.7),
        'dpo_task_success_rate': (_growth(63,82,0.009,0.8,rng), 81.9),
        'agentic_rlhf_task_success_rate': (_growth(65,91,0.011,0.75,rng), 90.7),
        'sft_violation_rate': (_decay(24,18,0.004,0.45,rng), 18.9),
        'standard_rlhf_violation_rate': (_decay(22,13,0.007,0.45,rng), 13.2),
        'dpo_violation_rate': (_decay(21,10,0.008,0.4,rng), 10.3),
        'agentic_rlhf_violation_rate': (_decay(20,5.8,0.010,0.35,rng), 5.9),
        'human_feedback_cost_index': (_decay(100,39,0.007,1.0,rng), 40.0),
        'ai_feedback_coverage_percent': (_growth(10,72,0.007,1.1,rng), 70.0),
    }
    logs = pd.DataFrame({'iteration': iters})
    for k,(v,target) in specs.items():
        logs[k] = _force_tail_mean(v, target)
    return logs