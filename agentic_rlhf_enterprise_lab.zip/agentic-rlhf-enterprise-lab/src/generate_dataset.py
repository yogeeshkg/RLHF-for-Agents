"""Generate all datasets used by the lab and paper figures."""
from agentic_rlhf import run_experiment

if __name__ == '__main__':
    outputs = run_experiment()
    print('Generated datasets:')
    print(outputs['summary'].round(1).to_string(index=False))