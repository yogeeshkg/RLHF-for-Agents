"""Hybrid human and AI feedback engine."""
from dataclasses import dataclass

@dataclass
class HybridFeedbackEngine:
    alpha_human: float = 0.65

    def alignment_reward(self, human_feedback_score: float, ai_feedback_score: float) -> float:
        """Compute normalized hybrid feedback reward in [0, 1]."""
        h = min(max(human_feedback_score, 0.0), 1.0)
        a = min(max(ai_feedback_score, 0.0), 1.0)
        return self.alpha_human * h + (1.0 - self.alpha_human) * a