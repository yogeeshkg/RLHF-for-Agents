"""Metric calculations corresponding to the paper formulas."""
from __future__ import annotations
import pandas as pd

def final_checkpoint_metrics(training_logs: pd.DataFrame, tail_window: int = 50) -> pd.DataFrame:
    tail = training_logs.tail(tail_window)
    return pd.DataFrame({
        'model': ['SFT','Standard RLHF','DPO','Agentic RLHF'],
        'alignment_score': [tail['sft_alignment_score'].mean(), tail['standard_rlhf_alignment_score'].mean(), tail['dpo_alignment_score'].mean(), tail['agentic_rlhf_alignment_score'].mean()],
        'task_success_rate': [tail['sft_task_success_rate'].mean(), tail['standard_rlhf_task_success_rate'].mean(), tail['dpo_task_success_rate'].mean(), tail['agentic_rlhf_task_success_rate'].mean()],
        'violation_rate': [tail['sft_violation_rate'].mean(), tail['standard_rlhf_violation_rate'].mean(), tail['dpo_violation_rate'].mean(), tail['agentic_rlhf_violation_rate'].mean()],
    })

def task_success_rate(df: pd.DataFrame) -> float:
    return 100.0 * df['task_success'].mean()

def violation_rate(df: pd.DataFrame) -> float:
    return 100.0 * df['policy_violation'].mean()

def alignment_score(df: pd.DataFrame) -> float:
    return df['alignment_score'].mean()

def feedback_cost_index(c_h: float, c_a: float, n_h: int, n_a: int) -> float:
    return 100.0 * ((c_h * n_h + c_a * n_a) / (c_h * (n_h + n_a)))