"""Generate all publication-ready plots used in the paper."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import DATA_PROCESSED, FIGURES

FIGURES.mkdir(parents=True, exist_ok=True)
logs = pd.read_csv(DATA_PROCESSED / 'training_logs.csv')

def plot_curve(cols, labels, ylabel, title, name):
    plt.figure(figsize=(7,4.5))
    for c,l in zip(cols, labels):
        plt.plot(logs['iteration'], logs[c], label=l, linewidth=1.4)
    plt.xlabel('Training Iteration')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(FIGURES / f'{name}.png', dpi=300)
    plt.savefig(FIGURES / f'{name}.svg')
    plt.close()

plot_curve(['sft_alignment_score','standard_rlhf_alignment_score','dpo_alignment_score','agentic_rlhf_alignment_score'], ['SFT','Standard RLHF','DPO','Agentic RLHF'], 'Alignment Score', 'Alignment Score Across Training Iterations', 'training_alignment_curve')
plot_curve(['sft_task_success_rate','standard_rlhf_task_success_rate','dpo_task_success_rate','agentic_rlhf_task_success_rate'], ['SFT','Standard RLHF','DPO','Agentic RLHF'], 'Task Success Rate (%)', 'Task Success Rate Across Training Iterations', 'training_task_success_curve')
plot_curve(['sft_violation_rate','standard_rlhf_violation_rate','dpo_violation_rate','agentic_rlhf_violation_rate'], ['SFT','Standard RLHF','DPO','Agentic RLHF'], 'Violation Rate (%)', 'Policy Violation Rate Across Training Iterations', 'training_violation_curve')
plot_curve(['human_feedback_cost_index','ai_feedback_coverage_percent'], ['Human Feedback Cost Index','AI Feedback Coverage (%)'], 'Index / Percent', 'Feedback Cost Index and AI Feedback Coverage', 'feedback_cost_coverage_curve')
print('Figures written to', FIGURES)