"""Domain-constrained trajectory reward model."""
from __future__ import annotations
from dataclasses import dataclass, field
from trajectory import Trajectory
from hybrid_feedback import HybridFeedbackEngine
from policy_constraints import PolicyConstraintLayer
from config import DEFAULT_REWARD_WEIGHTS, RewardWeights

@dataclass
class DomainConstrainedRewardModel:
    weights: RewardWeights = DEFAULT_REWARD_WEIGHTS
    policy_layer: PolicyConstraintLayer = field(default_factory=PolicyConstraintLayer)

    def task_reward(self, trajectory: Trajectory) -> float:
        return 0.70 * float(trajectory.task_success) + 0.30 * trajectory.final_response_quality

    def alignment_reward(self, trajectory: Trajectory) -> float:
        engine = HybridFeedbackEngine(alpha_human=self.weights.alpha_human)
        return engine.alignment_reward(trajectory.human_feedback_score, trajectory.ai_feedback_score)

    def violation_penalty(self, trajectory: Trajectory) -> float:
        return self.policy_layer.weighted_violation_penalty(trajectory)

    def uncertainty_penalty(self, trajectory: Trajectory) -> float:
        return min(max(trajectory.uncertainty_score, 0.0), 1.0)

    def final_reward(self, trajectory: Trajectory) -> float:
        return (
            self.weights.eta_task * self.task_reward(trajectory)
            + self.weights.beta_alignment * self.alignment_reward(trajectory)
            - self.weights.lambda_violation * self.violation_penalty(trajectory)
            - self.weights.rho_uncertainty * self.uncertainty_penalty(trajectory)
        )

    def reward_components(self, trajectory: Trajectory) -> dict:
        return {
            "task_reward": self.task_reward(trajectory),
            "alignment_reward": self.alignment_reward(trajectory),
            "violation_penalty": self.violation_penalty(trajectory),
            "uncertainty_penalty": self.uncertainty_penalty(trajectory),
            "final_reward": self.final_reward(trajectory),
        }