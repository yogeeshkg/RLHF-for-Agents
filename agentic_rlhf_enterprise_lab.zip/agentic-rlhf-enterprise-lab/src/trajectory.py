"""Trajectory data structures for agentic enterprise workflows."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Any

@dataclass
class TrajectoryStep:
    step_id: int
    state: str
    action: str
    observation: str
    tool_call: str | None = None
    policy_checks: Dict[str, int] = field(default_factory=dict)

@dataclass
class Trajectory:
    trajectory_id: str
    workflow_type: str
    model: str
    iteration: int
    steps: List[TrajectoryStep]
    final_response_quality: float
    task_success: int
    alignment_score: float
    human_feedback_score: float
    ai_feedback_score: float
    uncertainty_score: float

    def violation_count(self) -> int:
        return sum(sum(step.policy_checks.values()) for step in self.steps)

    def has_policy_violation(self) -> int:
        return int(self.violation_count() > 0)

    def to_record(self) -> Dict[str, Any]:
        """Flatten a trajectory into a row suitable for CSV logging."""
        return {
            "trajectory_id": self.trajectory_id,
            "iteration": self.iteration,
            "model": self.model,
            "workflow_type": self.workflow_type,
            "n_steps": len(self.steps),
            "tool_calls": ";".join([s.tool_call or "none" for s in self.steps]),
            "actions": ";".join([s.action for s in self.steps]),
            "policy_violation": self.has_policy_violation(),
            "violation_count": self.violation_count(),
            "task_success": self.task_success,
            "alignment_score": round(self.alignment_score, 4),
            "human_feedback_score": round(self.human_feedback_score, 4),
            "ai_feedback_score": round(self.ai_feedback_score, 4),
            "uncertainty_score": round(self.uncertainty_score, 4),
            "final_response_quality": round(self.final_response_quality, 4),
        }