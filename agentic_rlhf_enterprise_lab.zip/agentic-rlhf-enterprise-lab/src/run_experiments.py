"""Run the full CPU-friendly Agentic RLHF lab experiment."""
from agentic_rlhf import run_experiment

if __name__ == '__main__':
    outputs = run_experiment()
    print('Experiment complete.')
    print(outputs['summary'].round(1).to_string(index=False))