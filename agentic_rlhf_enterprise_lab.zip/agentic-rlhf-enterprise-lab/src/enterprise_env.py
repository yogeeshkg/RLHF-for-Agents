"""CPU-friendly enterprise workflow simulator for agentic alignment experiments."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from trajectory import Trajectory, TrajectoryStep
from config import WORKFLOWS

ACTIONS_BY_WORKFLOW = {
    "ITSM incident triage": [
        "parse_alert", "classify_severity", "retrieve_known_error", "recommend_resolver_group", "check_change_policy", "propose_remediation", "decide_escalation"
    ],
    "ERP transaction validation": [
        "read_transaction_context", "check_sox_control", "validate_master_data", "inspect_exception", "recommend_release_or_hold"
    ],
    "DevSecOps change review": [
        "read_change_request", "map_impacted_services", "inspect_security_scan", "check_approval", "recommend_release_gate"
    ],
}

TOOLS_BY_WORKFLOW = {
    "ITSM incident triage": ["monitoring_api", "knowledge_base", "itsm_ticketing", "cmdb"],
    "ERP transaction validation": ["erp_api", "control_repository", "audit_log", "master_data_service"],
    "DevSecOps change review": ["ci_cd_system", "security_scanner", "change_calendar", "service_catalog"],
}

POLICY_NAMES = [
    "unauthorized_tool_use", "unsafe_remediation", "missing_approval_check", "escalation_failure", "data_exposure_risk", "missing_audit_trail"
]

@dataclass
class EnterpriseWorkflowSimulator:
    seed: int = 42

    def __post_init__(self):
        self.rng = np.random.default_rng(self.seed)

    def simulate_trajectory(
        self,
        trajectory_id: str,
        model: str,
        iteration: int,
        workflow_type: str,
        alignment_score: float,
        task_success_probability: float,
        violation_probability: float,
    ) -> Trajectory:
        actions = ACTIONS_BY_WORKFLOW[workflow_type]
        tools = TOOLS_BY_WORKFLOW[workflow_type]
        task_success = int(self.rng.random() < task_success_probability / 100.0)
        has_violation = int(self.rng.random() < violation_probability / 100.0)
        violation_step = self.rng.integers(0, len(actions)) if has_violation else -1
        violation_name = self.rng.choice(POLICY_NAMES) if has_violation else None

        steps = []
        for idx, action in enumerate(actions):
            checks = {name: 0 for name in POLICY_NAMES}
            if idx == violation_step and violation_name:
                checks[violation_name] = 1
            steps.append(TrajectoryStep(
                step_id=idx + 1,
                state=f"{workflow_type}:state_{idx+1}",
                action=action,
                tool_call=tools[idx % len(tools)],
                observation=f"observation_for_{action}",
                policy_checks=checks,
            ))

        norm_alignment = min(max(alignment_score / 100.0, 0.0), 1.0)
        human_feedback = float(np.clip(self.rng.normal(norm_alignment, 0.03), 0, 1))
        ai_feedback = float(np.clip(self.rng.normal(norm_alignment, 0.04), 0, 1))
        uncertainty = float(np.clip(1.0 - norm_alignment + self.rng.normal(0, 0.02), 0, 1))
        final_quality = float(np.clip(0.65 * task_success + 0.35 * norm_alignment, 0, 1))
        return Trajectory(
            trajectory_id=trajectory_id,
            workflow_type=workflow_type,
            model=model,
            iteration=iteration,
            steps=steps,
            final_response_quality=final_quality,
            task_success=task_success,
            alignment_score=alignment_score,
            human_feedback_score=human_feedback,
            ai_feedback_score=ai_feedback,
            uncertainty_score=uncertainty,
        )