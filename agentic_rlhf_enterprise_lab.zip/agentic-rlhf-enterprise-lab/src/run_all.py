"""One-command reproduction for the complete lab."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
commands = [
    [sys.executable, str(ROOT / 'src' / 'run_experiments.py')],
    [sys.executable, str(ROOT / 'src' / 'generate_figures.py')],
    [sys.executable, str(ROOT / 'src' / 'analyze_results.py')],
]
for cmd in commands:
    print("\nRunning:", " ".join(cmd))
    subprocess.check_call(cmd, cwd=ROOT)
print("\nAll lab outputs regenerated successfully.")
