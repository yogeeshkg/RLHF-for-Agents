"""Optional future extension: DPO training with HuggingFace TRL.

This file is intentionally a skeleton. It is not required for the CPU-friendly lab.
Install optional dependencies from requirements-optional-hf.txt before using it.
"""

# Example outline:
# from datasets import load_dataset
# from transformers import AutoTokenizer, AutoModelForCausalLM
# from trl import DPOTrainer, DPOConfig
#
# dataset = load_dataset("Anthropic/hh-rlhf")
# model = AutoModelForCausalLM.from_pretrained("distilgpt2")
# tokenizer = AutoTokenizer.from_pretrained("distilgpt2")
# config = DPOConfig(output_dir="outputs/dpo", per_device_train_batch_size=1)
# trainer = DPOTrainer(model=model, args=config, processing_class=tokenizer, train_dataset=dataset["train"])
# trainer.train()