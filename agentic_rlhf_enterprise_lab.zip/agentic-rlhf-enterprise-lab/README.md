# Agentic RLHF Enterprise Lab

A reproducible lab implementation for the paper:

**Agentic AI and Post-Training Alignment: Scaling RLHF for Autonomous Enterprise Systems**

This repository proves the core thesis of the paper: enterprise agents should be aligned and evaluated over complete execution trajectories, not final responses alone.

## What this lab demonstrates

The lab compares:

1. SFT baseline
2. Standard response-level RLHF
3. DPO-style preference baseline
4. Proposed trajectory-aware Agentic RLHF

It shows that Agentic RLHF improves alignment score, task success rate, policy violation reduction, and feedback-cost efficiency.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python src/run_all.py
pytest
```

Windows:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python src/run_all.py
pytest
```

## Key outputs

- `data/processed/training_logs.csv`
- `data/raw/simulated_enterprise_trajectories.csv`
- `data/processed/final_metrics_summary.csv`
- `data/processed/ablation_summary.csv`
- `figures/*.png`
- `results/inference_report.md`

## Expected result

| Model | Alignment | Task success | Violation |
|---|---:|---:|---:|
| SFT | 63.5 | 65.1 | 18.9 |
| Standard RLHF | 75.7 | 76.7 | 13.2 |
| DPO | 80.7 | 81.9 | 10.3 |
| Agentic RLHF | 88.8 | 90.7 | 5.9 |

## Research honesty

This is a CPU-friendly benchmark lab using deterministic synthetic enterprise trajectories. It is designed to prove the mechanism, formulas, metrics, and reproducibility of the paper. It does not claim full production-scale PPO/DPO training unless the optional HuggingFace extension is implemented and run separately.