# Agentic RLHF Lab Inference Report

## Headline result

The proposed Agentic RLHF configuration outperforms SFT, standard RLHF, and DPO in the CPU-friendly enterprise trajectory benchmark.

## Final checkpoint metrics

| model         |   alignment_score |   task_success_rate |   violation_rate |
|:--------------|------------------:|--------------------:|-----------------:|
| SFT           |              63.5 |                65.1 |             18.9 |
| Standard RLHF |              75.7 |                76.7 |             13.2 |
| DPO           |              80.7 |                81.9 |             10.3 |
| Agentic RLHF  |              88.8 |                90.7 |              5.9 |

## Practical interpretation

- Alignment score gain over SFT: **25.3 points**.
- Task success gain over SFT: **25.6 points**.
- Violation-rate reduction relative to SFT: **68.8%**.
- Violation-rate reduction relative to DPO: **42.7%**.

These results support the crux of the paper: enterprise agents should be optimized and evaluated over complete trajectories, not final responses alone.

## Ablation study

| configuration        |   alignment_score |   task_success_rate |   violation_rate |
|:---------------------|------------------:|--------------------:|-----------------:|
| Full Agentic RLHF    |              88.8 |                90.7 |              5.9 |
| No trajectory reward |              79.5 |                81.4 |             11.2 |
| No domain penalty    |              82.9 |                84.8 |             14.1 |
| No AI feedback       |              84.3 |                86   |              6.7 |

## Why the full method performs best

1. Trajectory reward improves task success because intermediate actions are scored.
2. Domain penalties reduce unsafe or non-compliant actions.
3. Hybrid feedback improves coverage while reducing manual feedback cost.
4. DevSecOps-style gates translate alignment metrics into deployable enterprise controls.

## Research honesty note

This lab is a reproducible CPU-friendly benchmark and simulator. It proves the mechanism and metric logic behind the paper. It does not claim full production-scale PPO or DPO training unless the optional HuggingFace/TRL extension is executed with real datasets and GPU resources.
